<template>
  <div>
    <h1>指令的值1测试</h1>
    <h1>指令的值2测试</h1>
  </div>
</template>

<script>
export default {
  data () {
    return {
      
    }
  }
}
</script>

<style>

</style>