<template>
  <div>
    <slot name="head"> </slot>
    <slot name="body"> </slot>
  </div>
</template>

<script>
export default {}
</script>

<style></style>
