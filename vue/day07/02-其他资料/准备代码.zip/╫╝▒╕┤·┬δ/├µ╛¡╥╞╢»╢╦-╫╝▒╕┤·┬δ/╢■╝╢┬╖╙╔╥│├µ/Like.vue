<template>
  <div class="like-page">
    喜欢
  </div>
</template>

<script>
export default {
  name: 'LikePage',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
