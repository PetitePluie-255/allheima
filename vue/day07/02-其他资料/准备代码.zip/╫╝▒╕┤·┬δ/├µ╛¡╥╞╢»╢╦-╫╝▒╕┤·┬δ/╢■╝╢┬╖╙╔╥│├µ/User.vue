<template>
  <div class="user-page">
    我的
  </div>
</template>

<script>
export default {
  name: 'UserPage',
  data () {
    return {

    }
  },
  async created () {

  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
