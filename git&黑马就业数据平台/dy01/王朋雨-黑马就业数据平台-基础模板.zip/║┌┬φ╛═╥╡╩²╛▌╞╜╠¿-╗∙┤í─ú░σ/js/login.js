// 给登录按钮注册点击事件
document.querySelector("#btn-login").addEventListener("click", async function () {
  // 收集表单数据
  const data = serialize(document.querySelector("form"), { hash: true, empty: true })
  // 对表单进行非空判断
  if (data.username === "" || data.password === "") {
    showToast("用户名或密码为空")
    return
  }
  // 对用户名密码进行长度判断
  if (data.username.length < 8 || data.password.length < 6) {
    showToast("用户名或密码长度不符合规则")
    return
  }
  // 发送登录请求
  try {
    const res = await axios.post("/login", data)
    showToast(res.message)
    localStorage.setItem("username", res.data.username)
    localStorage.setItem("token", res.data.token)
    location.href = "./index.html"
  } catch (error) {
    showToast("登录异常,请稍后再试")
  }
})

// 回车登录
// document.addEventListener("keyup", function (e) {
//   if (e.key === "Enter") {
//     document.querySelector("#btn-login").click()
//   }
// })
