// 配置Axios基地址
axios.defaults.baseURL = "https://hmajax.itheima.net/"

// 添加请求拦截器
axios.interceptors.request.use(
  function (config) {
    const token = localStorage.getItem("token")
    if (token) {
      config.headers.Authorization = token
    }
    return config
  },
  function (error) {
    // 对请求错误做些什么
    return Promise.reject(error)
  }
)

// 添加响应拦截器
axios.interceptors.response.use(
  function (response) {
    // 2xx 范围内的状态码都会触发该函数。
    // 对响应数据做点什么
    return response.data
  },
  function (error) {
    // 超出 2xx 范围的状态码都会触发该函数。
    // 对响应错误做点什么
    if (error.response.status === 401) {
      localStorage.removeItem("username")
      localStorage.removeItem("token")
      showToast("请重新登陆")
      setTimeout(() => {
        location.href = "./login.html"
      }, 1000)
    }
    return Promise.reject(error)
  }
)

// 轻提示函数封装
function showToast(msg) {
  // 选中轻提示元素
  const toast = document.querySelector(".my-toast")
  // 实例化轻提示元素
  const toastList = new bootstrap.Toast(toast)
  // 修改提示信息
  document.querySelector(".toast-body").innerHTML = msg
  // 显示提示框
  toast.style.zIndex = 9999
  toastList.show()
}

// 封装页面访问控制函数
function chechLogin() {
  const token = localStorage.getItem("token")
  if (!token) {
    showToast("请重新登录")
    setTimeout(() => {
      location.href = "./login.html"
    }, 1000)
  }
}

// 封装渲染用户名函数
function renderUserName() {
  const username = localStorage.getItem("username")
  document.querySelector(".username").innerHTML = username
}

// 封装退出登录函数
function logout() {
  document.querySelector("#logout").addEventListener("click", function () {
    confirm("确认要退出登录吗?")
    if (confirm) {
      localStorage.removeItem("token")
      localStorage.removeItem("username")
      setTimeout(() => {
        location.href = "./login.html"
      }, 500)
    }
  })
}


