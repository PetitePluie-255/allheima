<template>
  <div class="search">
        <div class="search-box">
        <div class="location">
            <span>上海</span>
            <i class="iconfont icon-xiajiantou1"></i>
        </div>

        <div class="form">
            <i class="iconfont icon-chazhao"></i>
            <div class="span">请输入小区或地址</div>
        </div>
        </div>
        <i class="iconfont icon-ditu1"></i>
    </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>

</style>