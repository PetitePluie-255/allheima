<template>
  <div class="collect-page">
    收藏页面
  </div>
</template>

<script>
export default {
  name: 'CollectPage',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
