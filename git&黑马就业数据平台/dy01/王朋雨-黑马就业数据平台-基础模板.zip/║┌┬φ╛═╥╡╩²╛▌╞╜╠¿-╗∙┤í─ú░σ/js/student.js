// 调用页面访问控制函数
chechLogin()
// 调用用户名渲染函数渲染用户名
renderUserName()
// 调用退出登录函数
logout()
// 声明全局变量
let rowId

// 获取页面元素
// 渲染列表
const list = document.querySelector(".list")

// 表单
const form = document.querySelector("#form")

// 省
const province = document.querySelector("[name='province']")
// 市
const city = document.querySelector("[name='city']")
// 区
const area = document.querySelector("[name='area']")
// 确定按钮
const submit = document.querySelector("#submit")
// 渲染学生列表
async function studentList() {
  try {
    const res = await axios.get("/students")
    const data = res.data
    console.log(data)
    list.innerHTML = data
      .map((ele) => {
        return `<tr>
                      <td>${ele.name}</td>
                      <td>${ele.age}</td>
                      <td>${ele.gender ? "女" : "男"}</td>
                      <td>第${ele.group}组</td>
                      <td>${ele.hope_salary}</td>
                      <td>${ele.salary}</td>
                      <td>${ele.province}${ele.city}${ele.area}</td>
                      <td>
                        <a href="javascript:;" class="text-success mr-3"><i data-id='${ele.id}' class="bi bi-pen"></i></a>
                        <a href="javascript:;"  class="text-danger"><i data-id='${ele.id}' class="bi bi-trash"></i></a>
                      </td>
                    </tr>`
      })
      .join("")
    document.querySelector(".total").innerHTML = data.length
  } catch (error) {
    console.log(error)
  }
}

studentList()

// 删除功能
list.addEventListener("click", async (e) => {
  try {
    const target = e.target
    console.log(target)
    if (target.classList.contains("bi-trash")) {
      const id = target.dataset.id
      console.log(id)
      await axios({
        method: "DELETE",
        url: `/students/${id}`,
        data: {
          id,
        },
      })
      studentList()
      showToast("删除成功")
    }
  } catch (error) {
    showToast("删除异常")
  }
})
// 模态框
const addModel = document.querySelector("#modal")
const modal = new bootstrap.Modal(addModel)
// 显示添加模态框
document.querySelector(".bi-plus").addEventListener("click", async function () {
  rowId = null
  if (!rowId) {
    document.querySelector("#form").reset()
    document.querySelector(".modal-title").innerHTML = "添加学员"
    modal.show()
  }
})
// 显示编辑模态框
list.addEventListener("click", async (e) => {
  const target = e.target
  if (target.classList.contains("bi-pen")) {
    rowId = target.dataset.id
    if (rowId) {
      document.querySelector(".modal-title").innerHTML = "编辑学员"
      modal.show()
      const id = rowId
      const res = await axios.get(`/students/${id}`, {
        params: {
          id,
        },
      })
      const data = res.data
      let arr = Object.keys(data)
      arr = arr.filter((ele) => {
        return ele === "name" || ele === "age" || ele === "hope_salary" || ele === "salary" || ele === "group"
      })
      form.reset()
      arr.forEach((ele) => {
        document.querySelector(`[name="${ele}"]`).value = data[ele]
      })
      if (data.gender === 0) {
        document.querySelector("#cb01").checked = "true"
      } else {
        document.querySelector("#cb02").checked = "true"
      }

      const res1 = axios.get("/api/city", {
        params: {
          pname: data.province,
        },
      })

      const res2 = axios.get("/api/area", {
        params: {
          pname: data.province,
          cname: data.city,
        },
      })
      const p = Promise.all([res1, res2])
      p.then((res) => {
        const list = res.map((ele) => {
          return ele.list
        })
        city.innerHTML += list[0].map((ele) => `<option value="${ele}">${ele}</option>`).join("")
        area.innerHTML += list[1].map((ele) => `<option value="${ele}">${ele}</option>`).join("")

        province.value = data.province
        city.value = data.city
        area.value = data.area
      })
    } -"; "
  }
})

// 省市区
async function address() {
  async function getProvince() {
    const res = await axios.get("/api/province")
    const data = res.list
    province.innerHTML += data.map((ele) => `<option value="${ele}">${ele}</option>`).join("")
    // const list = (res.list.innerHTML += list.map((ele) => `<option value="${ele}">${ele}</option>`).join(""))
    console.log(province);
  }
  getProvince()

  province.addEventListener("change", async function () {
    const pname = this.value
    console.log(this.value)
    const res = await axios.get("/api/city", {
      params: {
        pname,
      },
    })
    const list = res.list
    city.innerHTML = `<option value="">城市</option>`
    city.innerHTML += list.map((ele) => `<option value="${ele}">${ele}</option>`).join("")
    area.innerHTML = `<option value="">地区</option>`
  })

  city.addEventListener("change", async function () {
    const pname = province.value
    const cname = this.value
    console.log(this.value)
    const res = await axios.get("/api/area", {
      params: {
        pname,
        cname,
      },
    })
    const list = res.list
    area.innerHTML += list.map((ele) => `<option value="${ele}">${ele}</option>`).join("")
  })
  return address
}
address()

// 添加功能
async function add() {
  submit.addEventListener("click", async function () {
    if (!rowId) {
      let data = serialize(form, { hash: true, empty: true })
      data.age = +data.age
      data.gender = +data.gender
      data.hope_salary = +data.hope_salary
      data.salary = +data.salary
      data.group = +data.group
      try {
        const res = await axios.post("/students", data)
        showToast(res.message)
        form.reset()
        modal.hide()
        studentList()
      } catch (error) {
        showToast(error.response.data.message)
      }
    }
  })
}

add()
// 编辑功能
async function edit() {
  submit.addEventListener("click", async function () {
    if (rowId) {
      let data = serialize(form, { hash: true, empty: true })
      data.age = +data.age
      data.gender = +data.gender
      data.hope_salary = +data.hope_salary
      data.salary = +data.salary
      data.group = +data.group
      try {
        const res = await axios.put(`/students/${rowId}`, data)
        showToast(res.message)
        form.reset()
        modal.hide()
        studentList()
      } catch (error) {
        showToast(error.response.data.message)
      }
    }
  })
}

edit()
