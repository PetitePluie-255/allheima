<template>
  <div class="detail-page">
    文章详情页
  </div>
</template>

<script>
export default {
  name: 'DetailPage',
  data () {
    return {

    }
  },
  async created () {

  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
