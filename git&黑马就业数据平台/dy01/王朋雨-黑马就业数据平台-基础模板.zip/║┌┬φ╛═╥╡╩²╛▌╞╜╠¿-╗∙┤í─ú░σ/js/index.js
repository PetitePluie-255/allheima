// 调用页面访问控制函数
chechLogin()
// 调用用户名渲染函数渲染用户名
renderUserName()
// 调用退出登录函数
logout()

// 封装请求统计数据函数 调用图表函数并传参
async function studentStatistics() {
  const { data } = await axios.get("/dashboard")
  console.log(data)
  // 学生就业信息统计
  renderOverview(data.overview)
  // 全学科薪资走势
  renderLineChartYear(data.year)
  // 班级薪资分布
  renderPieChartSalary(data.salaryData)
  // 班级每组薪资
  renderbarChartSalary(data.groupData)
  // 男女薪资分布
  renderPieChartGender(data.salaryData)
  // 籍贯分步
  renderAtlasHometown(data.provinceData)
}
studentStatistics()

// 学生就业信息统计
function renderOverview(overview) {
  Object.keys(overview).forEach((ele) => {
    document.querySelector(`.${ele}`).innerHTML = overview[ele]
  })
}

// 全学科薪资走势
function renderLineChartYear(line) {
  // 初始化echarts
  const myCharts = echarts.init(document.querySelector("#line"))
  // 配置配置项
  const option = {
    title: {
      top: "20",
      left: "20",
      text: "2022全学科薪资走势",
    },
    grid: {
      top: "100",
    },
    tooltip: {
      trigger: "axis",
    },
    xAxis: {
      axisLine: {
        lineStyle: {
          color: "#cecece ",
          type: "dashed",
        },
      },
      data: line.map((ele) => {
        return ele.month
      }),
    },
    yAxis: {
      splitLine: {
        lineStyle: {
          type: "dashed",
        },
      },
    },
    series: [
      {
        data: line.map((ele) => ele.salary),
        type: "line",
        smooth: true,
        symbolSize: 15,
        lineStyle: {
          // color: "#53a7ff",
          color: {
            type: "linear",
            x: 0,
            y: 0,
            x2: 1,
            y2: 0,
            colorStops: [
              {
                offset: 0,
                color: "#72afff", // 0% 处的颜色
              },

              {
                offset: 1,
                color: "#5480ff", // 100% 处的颜色
              },
            ],
            global: false,
          },
          width: 10,
        },
        areaStyle: {
          origin: "auto",
          color: {
            type: "linear",
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              {
                offset: 0,
                color: "#76cdff", // 0% 处的颜色
              },

              {
                offset: 1,
                color: "rgba(255,255,255,0)", // 100% 处的颜色
              },
            ],
            global: false,
          },
          shadowColor: "",
        },
      },
    ],
  }
  // 传入配置项
  myCharts.setOption(option)
}

// 班级薪资分布
function renderPieChartSalary(pie) {
  const myCharts = echarts.init(document.querySelector("#salary"))

  const option = {
    title: {
      top: "20",
      left: "20",
      text: "班级薪资分布",
    },

    tooltip: {
      trigger: "item",
    },
    legend: {
      bottom: "5%",
    },
    series: [
      {
        name: "班级薪资分布",
        type: "pie",
        data: pie.map((ele) => {
          return {
            value: ele.b_count + ele.g_count,
            name: ele.label,
          }
        }),
        radius: ["55%", "70%"],
        // content:['50%','50%'],
        itemStyle: {
          borderRadius: 15,
          borderColor: "#fff",
          borderWidth: 2,
        },
        label: {
          show: false,
        },
      },
    ],
    color: ["#ffb227", "#58a6ff", "#3fceff", "#39e8a9"],
  }

  myCharts.setOption(option)
}

// 班级每组薪资
function renderbarChartSalary(group) {
  const myCharts = echarts.init(document.querySelector("#lines"))

  // 默认配置项
  const option = {
    tooltip: {},
    xAxis: {
      data: group[1].map((ele) => ele.name),
      type: "category",
      axisLine: {
        lineStyle: {
          color: "#cecece ",
          type: "dashed",
        },
      },
    },
    yAxis: {
      splitLine: {
        lineStyle: {
          type: "dashed",
        },
      },
    },
    grid: {
      top: "30",
      left: "70",
      bottom: "50",
      right: "50",
    },

    series: [
      {
        data: group[1].map((ele) => ele.hope_salary),
        name: "期望薪资",
        type: "bar",
        // barWidth: "70",
        color: {
          type: "linear",
          x: 0,
          y: 0,
          x2: 0,
          y2: 2,
          colorStops: [
            {
              offset: 0,
              color: "#35d39a", // 0% 处的颜色
            },
            {
              offset: 1,
              color: "rgba(255,255,255,0)", // 100% 处的颜色
            },
          ],
          global: false, // 缺省为 false
        },
      },
      {
        data: group[1].map((ele) => ele.salary),
        name: "实际薪资",
        type: "bar",
        // barWidth: "20%",
        color: {
          type: "linear",
          x: 0,
          y: 0,
          x2: 0,
          y2: 2,
          colorStops: [
            {
              offset: 0,
              color: "#4ba0ee", // 0% 处的颜色
            },
            {
              offset: 1,
              color: "rgba(255,255,255,0)", // 100% 处的颜色
            },
          ],
          global: false, // 缺省为 false
        },
      },
    ],
  }

  // 默认设置配置项
  myCharts.setOption(option)

  // 数据切换
  document.querySelector("#btns").addEventListener("click", async function (e) {
    const target = e.target
    if (target.classList.contains("btn")) {
      // 小组切换
      document.querySelector(".btn-blue") && document.querySelector(".btn-blue").classList.remove("btn-blue")
      target.classList.add("btn-blue")
      // 图标数据切换
      const index = target.innerHTML
      option.xAxis.data = group[index].map((ele) => ele.name)
      option.series[0].data = group[index].map((ele) => ele.hope_salary)
      option.series[1].data = group[index].map((ele) => ele.salary)

      // 点击更新图表数据
      myCharts.setOption(option)
    }
  })
}

// 男女薪资分布
function renderPieChartGender(gender) {
  const myCharts = echarts.init(document.querySelector("#gender"))

  const option = {
    title: [
      {
        top: "20",
        left: "20",
        text: "男女薪资分布",
      },
      {
        subtext: "男生",
        left: "50%",
        top: "45%",
        textAlign: "center",
        subtextStyle: {
          color: "#000",
          fontSize: "14",
        },
      },
      {
        subtext: "女生",
        left: "50%",
        top: "85%",
        textAlign: "center",
        subtextStyle: {
          color: "#000",
          fontSize: "14",
        },
      },
    ],
    color: ["#fda224", "#5097ff", "#3abcfa", "#34d39a"],
    series: [
      {
        type: "pie",
        radius: ["20%", "30%"],
        center: ["50%", "30%"],
        data: gender.map((ele) => {
          return {
            value: ele.b_count,
            name: ele.label,
          }
        }),
      },
      {
        type: "pie",
        radius: ["20%", "30%"],
        center: ["50%", "70%"],
        data: gender.map((ele) => {
          return {
            value: ele.g_count,
            name: ele.label,
          }
        }),
      },
    ],
  }

  myCharts.setOption(option)
}

// 籍贯分布no
function renderAtlasHometown(hometown) {
  const data = hometown
  const dataList = [
    { name: "南海诸岛", value: 0 },
    { name: "北京", value: 0 },
    { name: "天津", value: 0 },
    { name: "上海", value: 0 },
    { name: "重庆", value: 0 },
    { name: "河北", value: 0 },
    { name: "河南", value: 0 },
    { name: "云南", value: 0 },
    { name: "辽宁", value: 0 },
    { name: "黑龙江", value: 0 },
    { name: "湖南", value: 0 },
    { name: "安徽", value: 0 },
    { name: "山东", value: 0 },
    { name: "新疆", value: 0 },
    { name: "江苏", value: 0 },
    { name: "浙江", value: 0 },
    { name: "江西", value: 0 },
    { name: "湖北", value: 0 },
    { name: "广西", value: 0 },
    { name: "甘肃", value: 0 },
    { name: "山西", value: 0 },
    { name: "内蒙古", value: 0 },
    { name: "陕西", value: 0 },
    { name: "吉林", value: 0 },
    { name: "福建", value: 0 },
    { name: "贵州", value: 0 },
    { name: "广东", value: 0 },
    { name: "青海", value: 0 },
    { name: "西藏", value: 0 },
    { name: "四川", value: 0 },
    { name: "宁夏", value: 0 },
    { name: "海南", value: 0 },
    { name: "台湾", value: 0 },
    { name: "香港", value: 0 },
    { name: "澳门", value: 0 },
  ]
  console.log(hometown)
  data.forEach((ele) => {
    if (ele.name.includes("省")) {
      ele.name = ele.name.replace("省", "")
    } else if (ele.name.includes("内蒙古")) {
      ele.name = ele.name.substring(0, 3)
    } else {
      ele.name = ele.name.substring(0, 2)
    }
  })

  dataList.forEach(item => {
    const obj = data.find(ele => {
      console.log(ele.name);
      console.log(item.name);
      console.log(ele.name === item.name)
      return ele.name === item.name
    })
    if (obj) item.value = obj.value
    console.log(obj);
    console.log(item);
  })
  console.log(data);

  const arr = hometown.map((ele) => {
    return ele.value
  })
  const max = Math.max(...arr)
  const myCharts = echarts.init(document.querySelector("#map"))
  const option = {
    title: {
      top: "20",
      left: "20",
      text: "籍贯分布",
    },
    tooltip: {
      trigger: "item",
      formatter: function (tip) {
        if (tip.value) {
          return `${tip.name}: ${tip.value}位学员`
        } else {
          return `${tip.name}: 0位学员`
        }
      },
      backgroundColor: "rgba(0,0,0,.5)",
      textStyle: {
        color: "#fff",
      },
    },
    visualMap: {
      //视觉映射组件
      top: "bottom",
      left: "left",
      min: 0,
      max: max,
      text: [`${max}`, 0],
      realtime: false, //拖拽时，是否实时更新
      calculable: true, //是否显示拖拽用的手柄
      inRange: {
        color: ["#fff", "#5da8f6", "#1682f1", "#0011f5", "#001cfb"],
      },
    },
    series: [
      {
        type: "map",
        mapType: "china",
        roam: false, //是否开启鼠标缩放和平移漫游
        itemStyle: {
          normal: {
            areaColor: "#fff",
            borderColor: "rgba(0,0,0,.2)",
            label: {
              show: true, //是否显示标签
              textStyle: {
                color: "#333",
              },
            },
          },
          //地图区域的多边形 图形样式
          zoom: 1.5, //地图缩放比例,默认为1
          emphasis: {
            //是图形在高亮状态下的样式,比如在鼠标悬浮或者图例联动高亮时
            label: { show: true },
            borderColor: "#34d39a",
            areaColor: "#34d39a",
          },
        },
        top: "3%", //组件距离容器的距离
        data: dataList,
      },
    ],
  }
  myCharts.setOption(option)
}
