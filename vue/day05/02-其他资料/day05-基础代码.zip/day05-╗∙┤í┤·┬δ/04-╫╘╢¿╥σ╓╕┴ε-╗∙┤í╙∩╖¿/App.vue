<template>
  <div>
    <h1>自定义指令</h1>
    <input type="text">
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>