<template>
  <div class="login-page">
    登录页
  </div>
</template>

<script>
export default {
  name: 'LoginPage',
  data () {
    return {}
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>
.link {
  color: #069;
  font-size: 12px;
  padding-right: 20px;
  float: right;
}
</style>
