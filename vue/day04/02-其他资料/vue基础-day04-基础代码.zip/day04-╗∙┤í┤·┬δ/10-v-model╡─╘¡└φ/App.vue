<template>
  <div class="app">
    <input type="text" />
    <br />
    <input type="text" >
  </div>
</template>

<script>
export default {
  data() {
    return {
      msg1: '',
    }
  },
}
</script>

<style>
</style>