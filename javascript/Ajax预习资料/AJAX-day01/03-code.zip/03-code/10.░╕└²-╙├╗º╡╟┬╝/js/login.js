/*
  1. 点击登录 和 服务器通信
  2. 判断 用户名 和 密码的长度
  3. 提示信息
*/


document.querySelector('.btn-login').addEventListener('click', () => {
  
})