<template>
  <div>User</div>
</template>

<script>
export default {
  name: 'UserPage'
}
</script>
