<template>
  <div class="article-page">
    面经页面
  </div>
</template>

<script>
export default {
  name: 'ArticlePage',
  data () {
    return {

    }
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>

</style>
