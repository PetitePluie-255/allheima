<template>
  <div class="layout-page">
    <div>首页架子 - 内容区域</div>

    <div>底部tabbar - 区域</div>
  </div>
</template>

<script>
export default {
  name: 'LayoutPage'
}
</script>

<style lang="less" scoped></style>
