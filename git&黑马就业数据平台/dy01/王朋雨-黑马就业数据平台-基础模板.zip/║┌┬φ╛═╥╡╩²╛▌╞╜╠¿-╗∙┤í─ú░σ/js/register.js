// 测试Axios基地址
// axios({
//     url: '/register',
//     method: 'post',
//     data: {
//         username:'admin0255',
//         password:'12345678'
//     }
// })
// 测试axios别名
// axios.post("/register", {
//   username: "admin025895",
//   password: "12345678",
// })
// axios.get("/api/city", {
//   params: {
//     pname: "北京",
//   },
// })

// 给注册按钮注册点击事件
document.querySelector("#btn-register").addEventListener("click", async function () {
  // 收集form表单数据
  const data = serialize(document.querySelector("form"), { hash: true, empty: true })
  
  // 对表单进行非空判断
  console.log(data)
  if (data.username === "" || data.password === "") {
    showToast("用户名或密码为空")
    return
  }
  // 对用户名密码进行长度判断
  if (data.username.length < 8 || data.password.length < 6) {
    showToast("用户名或密码长度不符合规则")
    return
  }
  // 发送注册请求
  try {
    const res = await axios.post("/register", data)
    showToast(res.message)
    setTimeout(() => {
      location.href = "./login.html"
    }, 1000)
  } catch (error) {
    showToast("注册异常")
  }
});
